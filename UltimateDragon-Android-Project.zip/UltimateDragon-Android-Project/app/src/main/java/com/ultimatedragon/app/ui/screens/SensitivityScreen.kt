package com.ultimatedragon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultimatedragon.app.ui.theme.*

@Composable
fun SensitivityScreen() {
    val scrollState = rememberScrollState()

    var phoneDpi by remember { mutableStateOf(411f) }
    var touchPollingRate by remember { mutableStateOf(240f) }
    var playStyle by remember { mutableStateOf(1) } // 0: Precision/Long Range, 1: Balanced, 2: Rusher/Fast Drag

    // Calculated sensitivity values (Free Fire scale 0 - 100)
    val baseGeneral = when (playStyle) {
        0 -> 88
        1 -> 95
        else -> 98
    }

    val generalSens = (baseGeneral * (400f / phoneDpi).coerceIn(0.85f, 1.15f)).toInt().coerceIn(75, 100)
    val redDotSens = (generalSens * 0.94f).toInt().coerceIn(70, 99)
    val scope2xSens = (generalSens * 0.88f).toInt().coerceIn(65, 96)
    val scope4xSens = (generalSens * 0.82f).toInt().coerceIn(60, 92)
    val sniperSens = (generalSens * 0.62f).toInt().coerceIn(45, 80)
    val freeLookSens = 80

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DragonBlack)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "SENSITIVITY CALIBRATOR",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            color = DragonTextWhite
        )
        Text(
            text = "Physics-based Free Fire in-game sensitivity calibration",
            style = MaterialTheme.typography.bodyMedium,
            color = DragonTextMuted,
            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
        )

        // Device Parameter Controls Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = DragonSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "DEVICE DISPLAY PARAMETERS",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = DragonRedPrimary
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Android Smallest Width (DPI)", style = MaterialTheme.typography.bodyMedium, color = DragonTextWhite)
                    Text("${phoneDpi.toInt()} DPI", color = DragonRedPrimary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }

                Slider(
                    value = phoneDpi,
                    onValueChange = { phoneDpi = it },
                    valueRange = 320f..560f,
                    steps = 12,
                    colors = SliderDefaults.colors(
                        thumbColor = DragonRedPrimary,
                        activeTrackColor = DragonRedPrimary,
                        inactiveTrackColor = DragonSurfaceVariant
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Combat Style", style = MaterialTheme.typography.bodyMedium, color = DragonTextWhite)
                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Precision", "Balanced", "Fast Rusher").forEachIndexed { index, title ->
                        FilterChip(
                            selected = playStyle == index,
                            onClick = { playStyle = index },
                            label = { Text(title, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = DragonRedPrimary,
                                selectedLabelColor = DragonTextWhite,
                                containerColor = DragonSurfaceVariant,
                                labelColor = DragonTextMuted
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                borderColor = if (playStyle == index) DragonRedPrimary else DragonBorder,
                                enabled = true,
                                selected = playStyle == index
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // In-Game Sensitivity Matrix Result
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = DragonSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECOMMENDED IN-GAME SENSITIVITY",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = DragonRedPrimary
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                SensitivityResultRow(label = "General (Drag-Shot)", value = generalSens)
                SensitivityResultRow(label = "Red Dot Sight", value = redDotSens)
                SensitivityResultRow(label = "2X Scope", value = scope2xSens)
                SensitivityResultRow(label = "4X Scope", value = scope4xSens)
                SensitivityResultRow(label = "Sniper Scope (AWM/Kar98)", value = sniperSens)
                SensitivityResultRow(label = "Free Look Camera", value = freeLookSens)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DragonDarkBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Info, contentDescription = null, tint = DragonRedPrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Apply these values inside Free Fire -> Settings -> Sensitivity. These values are computed mathematically for linear swipe acceleration and do not modify any game code.",
                    style = MaterialTheme.typography.bodySmall,
                    color = DragonTextMuted,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
fun SensitivityResultRow(label: String, value: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium, color = DragonTextWhite)
        Text(
            text = "$value",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = DragonRedPrimary,
            fontFamily = FontFamily.Monospace
        )
    }
}
