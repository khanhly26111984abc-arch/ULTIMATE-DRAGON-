package com.ultimatedragon.app.ui.theme

import androidx.compose.ui.graphics.Color

val DragonBlack = Color(0xFF070406)
val DragonDarkBg = Color(0xFF0D060A)
val DragonSurface = Color(0xFF14080F)
val DragonSurfaceVariant = Color(0xFF1E0A16)
val DragonBorder = Color(0xFF38101E)
val DragonRedPrimary = Color(0xFFFF1A40)
val DragonRedNeon = Color(0xFFFF2A4D)
val DragonRedDark = Color(0xFF88081F)
val DragonTextWhite = Color(0xFFF4F4F5)
val DragonTextMuted = Color(0xFFA1A1AA)
val DragonSuccess = Color(0xFF10B981)
val DragonWarning = Color(0xFFF59E0B)
val DragonError = Color(0xFFEF4444)
