package com.ultimatedragon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultimatedragon.app.ui.theme.*

data class FeatureItem(
    val id: String,
    val name: String,
    val subtitle: String,
    val icon: ImageVector,
    val desc: String
)

@Composable
fun HomeScreen(
    activeKey: String,
    onNavigateToSettings: () -> Unit,
    onNavigateToSensitivity: () -> Unit,
    onNavigateToGuides: () -> Unit
) {
    val scrollState = rememberScrollState()

    val features = listOf(
        FeatureItem("aimlock", "AIMLOCK", "Bám đầu thông minh", Icons.Default.FilterCenterFocus, "Hỗ trợ tính toán góc vuốt tâm chuẩn xác lên vị trí đầu."),
        FeatureItem("stability", "STABILITY ASSIST", "Ổn định tâm ngắm", Icons.Default.GpsFixed, "Giảm thiểu giật khung hình và ổn định tọa độ chạm cảm ứng."),
        FeatureItem("aim_hold", "AIM HOLD", "Ghim tâm cố định", Icons.Default.Lock, "Cố định tâm ngắm ở tầm trung và xa, hạn chế tâm bị bay quá đầu."),
        FeatureItem("aim_lockdown", "AIM LOCKDOWN", "Đằm tâm - Khóa mục tiêu", Icons.Default.Shield, "Khóa mục tiêu đầm chắc khi cận chiến súng shotgun hoặc SMG."),
        FeatureItem("sens_booster", "SENSITIVITY BOOSTER", "Tăng độ nhạy - Tác vụ nhanh", Icons.Default.Speed, "Tăng tốc độ phản hồi cảm ứng khi quay màn hình 360 độ."),
        FeatureItem("screen_booster", "SCREEN BOOSTER", "Nâng cao chất lượng hình ảnh", Icons.Default.Tv, "Cải thiện độ sắc nét và ổn định tần số quét màn hình 90Hz/120Hz."),
        FeatureItem("headshot_fix", "HEADSHOT FIX", "Fix lỗi đầu - Chính xác hơn", Icons.Default.Adjust, "Căn chỉnh hồng tâm không bị lệch vào ngực khi vuốt nút bắn."),
        FeatureItem("bullet_align", "BULLET ALIGN", "Fix lạc đạn - Căn đường đạn", Icons.Default.DoubleArrow, "Giảm độ tản đạn của súng trường khi sấy loạt đạn đầu."),
        FeatureItem("shake_fix", "SHAKE FIX", "Khử rung - Ổn định tâm", Icons.Default.Vibration, "Khử hiện tượng rung lắc camera khi ngón tay di chuyển trên màn hình.")
    )

    var selectedFeature by remember { mutableStateOf<FeatureItem?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DragonBlack)
            .verticalScroll(scrollState)
            .padding(14.dp)
    ) {
        // Hero Header Card (Matching Image 2)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DragonDarkBg),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DragonSurfaceVariant)
                                .border(1.dp, DragonRedPrimary, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = DragonRedPrimary, modifier = Modifier.size(26.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row {
                                Text("ULTIMATE ", fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 18.sp, color = DragonTextWhite)
                                Text("DRAGON", fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, fontSize = 18.sp, color = DragonRedPrimary)
                            }
                            Text("FREE FIRE SUPPORT TOOLKIT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DragonTextMuted, letterSpacing = 0.5.sp)
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(onClick = onNavigateToSettings, modifier = Modifier.size(32.dp).background(DragonSurface, CircleShape)) {
                            Icon(Icons.Default.Settings, contentDescription = null, tint = DragonTextWhite, modifier = Modifier.size(16.dp))
                        }
                        IconButton(onClick = {}, modifier = Modifier.size(32.dp).background(DragonSurface, CircleShape)) {
                            Icon(Icons.Default.Notifications, contentDescription = null, tint = DragonTextWhite, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text("BỨT PHÁ GIỚI HẠN", fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DragonTextWhite)
                Text("LÀM CHỦ TRẬN ĐẤU", fontStyle = FontStyle.Italic, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = DragonRedPrimary)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Guest Bar (Matching Image 2)
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = DragonSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(32.dp).background(DragonSurfaceVariant, CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = DragonTextMuted, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Guest", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = DragonTextWhite)
                        Text("Chưa đăng nhập", fontSize = 10.sp, color = DragonTextMuted)
                    }
                }

                TextButton(
                    onClick = onNavigateToSettings,
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DragonRedDark),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text("Đăng nhập >", fontSize = 11.sp, color = DragonRedPrimary, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 3x3 Feature Grid
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in 0 until 3) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (j in 0 until 3) {
                        val index = i * 3 + j
                        if (index < features.size) {
                            val feat = features[index]
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(105.dp)
                                    .clickable { selectedFeature = feat },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = DragonSurface),
                                border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
                            ) {
                                Column(
                                    modifier = Modifier.padding(8.dp).fillMaxSize(),
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Box(
                                            modifier = Modifier.size(32.dp).background(DragonSurfaceVariant, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(feat.icon, contentDescription = null, tint = DragonRedPrimary, modifier = Modifier.size(16.dp))
                                        }
                                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = DragonRedDark, modifier = Modifier.size(14.dp))
                                    }
                                    Column {
                                        Text(feat.name, fontWeight = FontWeight.Black, fontSize = 10.sp, color = DragonTextWhite, maxLines = 1)
                                        Text(feat.subtitle, fontSize = 8.sp, color = DragonTextMuted, maxLines = 1)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Bottom 3 Wide Tools (Matching Image 2)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            WideActionCard(modifier = Modifier.weight(1f), icon = Icons.Default.Folder, title = "PROFILE MANAGER", sub = "Lưu & quản lý", onClick = onNavigateToSensitivity)
            WideActionCard(modifier = Modifier.weight(1f), icon = Icons.Default.PhoneAndroid, title = "DEVICE CHECK", sub = "Kiểm tra máy", onClick = onNavigateToSettings)
            WideActionCard(modifier = Modifier.weight(1f), icon = Icons.Default.Book, title = "HƯỚNG DẪN", sub = "Tips & Cài đặt", onClick = onNavigateToGuides)
        }

        Spacer(modifier = Modifier.height(80.dp))
    }

    // Modal when clicked
    selectedFeature?.let { feat ->
        AlertDialog(
            onDismissRequest = { selectedFeature = null },
            confirmButton = {
                TextButton(onClick = { selectedFeature = null }) {
                    Text("ĐÃ BẬT TÍNH NĂNG", color = DragonRedPrimary, fontWeight = FontWeight.Bold)
                }
            },
            title = { Text(feat.name, color = DragonTextWhite, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(feat.subtitle, color = DragonRedPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(feat.desc, color = DragonTextMuted, fontSize = 12.sp)
                }
            },
            containerColor = DragonSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }
}

@Composable
fun WideActionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    sub: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DragonSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
    ) {
        Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = DragonRedPrimary, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 8.sp, color = DragonTextWhite, maxLines = 1)
                Text(sub, fontSize = 7.sp, color = DragonTextMuted, maxLines = 1)
            }
        }
    }
}
