package com.ultimatedragon.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DragonColorScheme = darkColorScheme(
    primary = DragonRedPrimary,
    onPrimary = DragonTextWhite,
    secondary = DragonRedDark,
    onSecondary = DragonTextWhite,
    background = DragonBlack,
    onBackground = DragonTextWhite,
    surface = DragonSurface,
    onSurface = DragonTextWhite,
    surfaceVariant = DragonSurfaceVariant,
    onSurfaceVariant = DragonTextMuted,
    outline = DragonBorder
)

@Composable
fun UltimateDragonTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = DragonBlack.toArgb()
                window.navigationBarColor = DragonBlack.toArgb()
                WindowCompat.getInsetsController(window, view).apply {
                    isAppearanceLightStatusBars = false
                    isAppearanceLightNavigationBars = false
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = DragonColorScheme,
        typography = Typography,
        content = content
    )
}
