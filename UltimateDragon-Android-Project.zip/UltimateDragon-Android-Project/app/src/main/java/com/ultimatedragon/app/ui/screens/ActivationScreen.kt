package com.ultimatedragon.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultimatedragon.app.ui.theme.*

@Composable
fun ActivationScreen(
    onActivationSuccess: (key: String) -> Unit
) {
    var keyInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val validDemoKeys = listOf("DRAGON-2026-VIP", "ULTIMATE-PRO-999")

    fun attemptActivation() {
        val trimmed = keyInput.trim().uppercase()
        if (trimmed.isEmpty()) {
            errorMessage = "Please enter your activation key."
            return
        }

        isLoading = true
        errorMessage = null

        // Verification logic
        if (validDemoKeys.contains(trimmed)) {
            errorMessage = null
            isLoading = false
            onActivationSuccess(trimmed)
        } else {
            isLoading = false
            errorMessage = "Access Denied: Invalid key. Check key or tap Demo Key below."
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(DragonBlack, DragonDarkBg, DragonSurface)
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Dragon Logo Header Container
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(DragonSurfaceVariant)
                    .border(2.dp, DragonRedPrimary, RoundedCornerShape(20.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Dragon Crest",
                    tint = DragonRedPrimary,
                    modifier = Modifier.size(54.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "ULTIMATE DRAGON",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = DragonTextWhite,
                letterSpacing = 1.sp
            )

            Text(
                text = "NATIVE GAMING COMPANION · JETPACK COMPOSE",
                style = MaterialTheme.typography.labelSmall,
                color = DragonRedPrimary,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Activation Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = DragonSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Text(
                        text = "LICENSE KEY ACTIVATION",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = DragonTextWhite
                    )

                    Text(
                        text = "Enter your unique authorization key to unlock sensitivity tools and legit performance guides.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = DragonTextMuted,
                        modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                    )

                    // Real, visible, editable TextField
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = {
                            keyInput = it
                            if (errorMessage != null) errorMessage = null
                        },
                        label = { Text("Product Key") },
                        placeholder = { Text("e.g. DRAGON-2026-VIP") },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = null,
                                tint = DragonRedPrimary
                            )
                        },
                        singleLine = true,
                        isError = errorMessage != null,
                        keyboardOptions = KeyboardOptions(
                            capitalization = KeyboardCapitalization.Characters,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = { attemptActivation() }
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = DragonRedPrimary,
                            unfocusedBorderColor = DragonBorder,
                            focusedTextColor = DragonTextWhite,
                            unfocusedTextColor = DragonTextWhite,
                            cursorColor = DragonRedPrimary,
                            errorBorderColor = DragonError
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Error Message feedback
                    AnimatedVisibility(
                        visible = errorMessage != null,
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error",
                                tint = DragonError,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = errorMessage ?: "",
                                color = DragonError,
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Working Activation Button
                    Button(
                        onClick = { attemptActivation() },
                        enabled = !isLoading,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DragonRedPrimary,
                            contentColor = DragonTextWhite
                        )
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = DragonTextWhite,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "VERIFY & ACTIVATE",
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Documented Demo Key Helper button
                    OutlinedButton(
                        onClick = {
                            keyInput = "DRAGON-2026-VIP"
                            errorMessage = null
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = DragonRedPrimary
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
                    ) {
                        Text(
                            text = "USE DEMO KEY: DRAGON-2026-VIP",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "100% Fair-Play Compliant · No Hacks · No Memory Modification",
                style = MaterialTheme.typography.labelSmall,
                color = DragonTextMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}
