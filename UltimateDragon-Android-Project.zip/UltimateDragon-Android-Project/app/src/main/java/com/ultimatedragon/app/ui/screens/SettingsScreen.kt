package com.ultimatedragon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ultimatedragon.app.ui.theme.*

@Composable
fun SettingsScreen(
    activeKey: String,
    onDeactivateKey: () -> Unit
) {
    val scrollState = rememberScrollState()

    var hapticFeedback by remember { mutableStateOf(true) }
    var soundEffects by remember { mutableStateOf(true) }
    var highRefreshMode by remember { mutableStateOf(true) }
    var batterySaverWarning by remember { mutableStateOf(true) }
    var selectedDpi by remember { mutableStateOf("411 (Standard)") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DragonBlack)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "SETTINGS & PREFERENCES",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black,
            color = DragonTextWhite
        )
        Text(
            text = "Configure companion preferences and verified Android tuning",
            style = MaterialTheme.typography.bodyMedium,
            color = DragonTextMuted,
            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
        )

        // License Information Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = DragonSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "ACTIVE VIP LICENSE",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = DragonRedPrimary
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = activeKey,
                    style = MaterialTheme.typography.titleMedium,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = DragonTextWhite
                )
                Text(
                    text = "Status: Lifetime VIP Authorization (Verified)",
                    style = MaterialTheme.typography.bodySmall,
                    color = DragonSuccess,
                    modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )

                OutlinedButton(
                    onClick = onDeactivateKey,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DragonError),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DragonError.copy(alpha = 0.5f))
                ) {
                    Icon(
                        imageVector = Icons.Default.LockReset,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("CHANGE OR DEACTIVATE KEY", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Hardware & Display Preferences
        Text(
            text = "APP BEHAVIOR & HARDWARE",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = DragonTextMuted,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = DragonSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                SettingSwitchRow(
                    title = "Haptic Tactile Feedback",
                    subtitle = "Vibrate on button clicks and matrix calculations",
                    checked = hapticFeedback,
                    onCheckedChange = { hapticFeedback = it }
                )

                Divider(color = DragonBorder, modifier = Modifier.padding(vertical = 12.dp))

                SettingSwitchRow(
                    title = "Cyber Audio Synth Clicks",
                    subtitle = "Play low-latency mechanical sound feedback",
                    checked = soundEffects,
                    onCheckedChange = { soundEffects = it }
                )

                Divider(color = DragonBorder, modifier = Modifier.padding(vertical = 12.dp))

                SettingSwitchRow(
                    title = "High Refresh Rate Lock (120Hz)",
                    subtitle = "Request maximum hardware refresh rate from Android WindowManager",
                    checked = highRefreshMode,
                    onCheckedChange = { highRefreshMode = it }
                )

                Divider(color = DragonBorder, modifier = Modifier.padding(vertical = 12.dp))

                SettingSwitchRow(
                    title = "Thermal & Battery Warning",
                    subtitle = "Alert when device battery drops below 20% or thermal throttling triggers",
                    checked = batterySaverWarning,
                    onCheckedChange = { batterySaverWarning = it }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Legitimate Free Fire Guidelines
        Text(
            text = "LEGITIMATE FREE FIRE OPTIMIZATION",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = DragonTextMuted,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = DragonSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, DragonBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                GuidelineRow(
                    title = "Android 'Smallest Width' (DPI) Rule",
                    body = "Never exceed 600 DPI in Developer Options. Recommended range: 392 to 440 DPI to prevent UI glitching while sharpening touch responsiveness."
                )
                Divider(color = DragonBorder, modifier = Modifier.padding(vertical = 10.dp))
                GuidelineRow(
                    title = "Free Fire In-Game Graphics vs FPS",
                    body = "Always set Graphic Style to 'Smooth' or 'Standard' with 'High FPS' enabled. High FPS unlocks 60/90/120 frames without GPU overheating."
                )
                Divider(color = DragonBorder, modifier = Modifier.padding(vertical = 10.dp))
                GuidelineRow(
                    title = "Strict Fair Play Rule",
                    body = "Ultimate Dragon strictly avoids any game file modification, script injection, or memory tampering. All settings are 100% compliant with Garena TOS."
                )
            }
        }

        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.SemiBold,
                color = DragonTextWhite
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = DragonTextMuted
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = DragonTextWhite,
                checkedTrackColor = DragonRedPrimary,
                uncheckedThumbColor = DragonTextMuted,
                uncheckedTrackColor = DragonSurfaceVariant
            )
        )
    }
}

@Composable
fun GuidelineRow(title: String, body: String) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = DragonRedPrimary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodySmall,
            color = DragonTextMuted,
            lineHeight = 18.sp
        )
    }
}
