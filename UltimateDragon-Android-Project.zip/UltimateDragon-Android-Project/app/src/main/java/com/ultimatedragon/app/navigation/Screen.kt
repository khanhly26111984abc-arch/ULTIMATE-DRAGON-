package com.ultimatedragon.app.navigation

sealed class Screen(val route: String, val title: String) {
    object Activation : Screen("activation", "Activation")
    object Home : Screen("home", "Dashboard")
    object Sensitivity : Screen("sensitivity", "Sensitivity")
    object Guides : Screen("guides", "FF Tips & Rules")
    object Settings : Screen("settings", "Preferences")
}
