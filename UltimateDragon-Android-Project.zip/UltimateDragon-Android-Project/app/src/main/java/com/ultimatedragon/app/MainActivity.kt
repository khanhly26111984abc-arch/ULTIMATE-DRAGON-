package com.ultimatedragon.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.ultimatedragon.app.navigation.Screen
import com.ultimatedragon.app.ui.screens.*
import com.ultimatedragon.app.ui.theme.DragonBlack
import com.ultimatedragon.app.ui.theme.DragonBorder
import com.ultimatedragon.app.ui.theme.DragonRedPrimary
import com.ultimatedragon.app.ui.theme.DragonSurface
import com.ultimatedragon.app.ui.theme.DragonTextMuted
import com.ultimatedragon.app.ui.theme.DragonTextWhite
import com.ultimatedragon.app.ui.theme.UltimateDragonTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences("ultimate_dragon_prefs", Context.MODE_PRIVATE)

        setContent {
            UltimateDragonTheme {
                val navController = rememberNavController()
                var activeKey by remember {
                    mutableStateOf(prefs.getString("active_license_key", null))
                }

                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route

                val isActivated = activeKey != null

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = DragonBlack,
                    bottomBar = {
                        if (isActivated && currentRoute != Screen.Activation.route) {
                            NavigationBar(
                                containerColor = DragonSurface,
                                contentColor = DragonTextWhite
                            ) {
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Home.route,
                                    onClick = {
                                        navController.navigate(Screen.Home.route) {
                                            popUpTo(Screen.Home.route) { inclusive = true }
                                        }
                                    },
                                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Home") },
                                    label = { Text("Home") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = DragonRedPrimary,
                                        selectedTextColor = DragonRedPrimary,
                                        indicatorColor = DragonSurface,
                                        unselectedIconColor = DragonTextMuted,
                                        unselectedTextColor = DragonTextMuted
                                    )
                                )
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Sensitivity.route,
                                    onClick = {
                                        navController.navigate(Screen.Sensitivity.route) {
                                            launchSingleTop = true
                                        }
                                    },
                                    icon = { Icon(Icons.Default.Tune, contentDescription = "Sens") },
                                    label = { Text("Sensitivity") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = DragonRedPrimary,
                                        selectedTextColor = DragonRedPrimary,
                                        indicatorColor = DragonSurface,
                                        unselectedIconColor = DragonTextMuted,
                                        unselectedTextColor = DragonTextMuted
                                    )
                                )
                                NavigationBarItem(
                                    selected = currentRoute == Screen.Settings.route,
                                    onClick = {
                                        navController.navigate(Screen.Settings.route) {
                                            launchSingleTop = true
                                        }
                                    },
                                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                                    label = { Text("Settings") },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = DragonRedPrimary,
                                        selectedTextColor = DragonRedPrimary,
                                        indicatorColor = DragonSurface,
                                        unselectedIconColor = DragonTextMuted,
                                        unselectedTextColor = DragonTextMuted
                                    )
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = if (isActivated) Screen.Home.route else Screen.Activation.route,
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable(Screen.Activation.route) {
                            ActivationScreen(
                                onActivationSuccess = { key ->
                                    prefs.edit().putString("active_license_key", key).apply()
                                    activeKey = key
                                    navController.navigate(Screen.Home.route) {
                                        popUpTo(Screen.Activation.route) { inclusive = true }
                                    }
                                }
                            )
                        }

                        composable(Screen.Home.route) {
                            HomeScreen(
                                activeKey = activeKey ?: "VIP-DEMO",
                                onNavigateToSettings = { navController.navigate(Screen.Settings.route) },
                                onNavigateToSensitivity = { navController.navigate(Screen.Sensitivity.route) },
                                onNavigateToGuides = { navController.navigate(Screen.Settings.route) }
                            )
                        }

                        composable(Screen.Sensitivity.route) {
                            SensitivityScreen()
                        }

                        composable(Screen.Settings.route) {
                            SettingsScreen(
                                activeKey = activeKey ?: "VIP-DEMO",
                                onDeactivateKey = {
                                    prefs.edit().remove("active_license_key").apply()
                                    activeKey = null
                                    navController.navigate(Screen.Activation.route) {
                                        popUpTo(0) { inclusive = true }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
